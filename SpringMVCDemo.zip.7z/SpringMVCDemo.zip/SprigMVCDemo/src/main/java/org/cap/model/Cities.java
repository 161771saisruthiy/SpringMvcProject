package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Cities {

	
	private String cityname;
	@Id
	@GeneratedValue
	private Integer cityId;
	
	Cities(){
		
	}

	public Cities(String cityname, Integer cityId) {
		super();
		this.cityname = cityname;
		this.cityId = cityId;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	@Override
	public String toString() {
		return "Cities [cityname=" + cityname + ", cityId=" + cityId + "]";
	}
	
	
	
}
