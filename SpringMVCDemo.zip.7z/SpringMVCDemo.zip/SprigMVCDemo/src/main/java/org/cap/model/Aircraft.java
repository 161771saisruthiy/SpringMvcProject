package org.cap.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Aircraft {

	@Id
	private Integer aircraftId;
	private String aircraftName;
	private String maxCrusernge;
	private String minCrusernge;
	
	 @ManyToMany
	    @JoinTable(name="PilotCertification" ,
		joinColumns= {@JoinColumn(name="aircraftId")},
		inverseJoinColumns= {@JoinColumn(name="pilotId")})
		List<Pilot> pilot=new ArrayList<>();
	
	public Aircraft() {
		super();
	}


	public Aircraft(Integer aircraftId, String aircraftName, String maxCrusernge, String minCrusernge) {
		super();
		this.aircraftId = aircraftId;
		this.aircraftName = aircraftName;
		this.maxCrusernge = maxCrusernge;
		this.minCrusernge = minCrusernge;
	}



	public Integer getAircraftId() {
		return aircraftId;
	}



	public void setAircraftId(Integer aircraftId) {
		this.aircraftId = aircraftId;
	}



	public String getAircraftName() {
		return aircraftName;
	}



	public void setAircraftName(String aircraftName) {
		this.aircraftName = aircraftName;
	}



	public String getMaxCrusernge() {
		return maxCrusernge;
	}



	public void setMaxCrusernge(String maxCrusernge) {
		this.maxCrusernge = maxCrusernge;
	}



	public String getMinCrusernge() {
		return minCrusernge;
	}



	public void setMinCrusernge(String minCrusernge) {
		this.minCrusernge = minCrusernge;
	}



	@Override
	public String toString() {
		return "Aircraft [aircraftId=" + aircraftId + ", aircraftName=" + aircraftName + ", maxCrusernge="
				+ maxCrusernge + ", minCrusernge=" + minCrusernge + "]";
	}
	
	
	
	
	
}
